package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SinglyLinkedListTest {
    private SinglyLinkedList list;

    @BeforeEach
    void setUp() {
        list = new SinglyLinkedList();
    }

    @Test
    void testInsertAtEnd() {
        list.insertAtEnd(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);
        assertTrue(list.search(10));
        assertTrue(list.search(20));
        assertTrue(list.search(30));
    }

    @Test
    void testSearch() {
        list.insertAtEnd(100);
        assertTrue(list.search(100));
        assertFalse(list.search(200));
    }
}
