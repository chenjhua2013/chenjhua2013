package com.example;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class AppTest {
    @Test
    void testExample() {
        assertTrue(1 + 1 == 2, "Basic math should work");
    }
}
