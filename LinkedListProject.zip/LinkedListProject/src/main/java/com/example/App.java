package com.example;

public class App {
    public static void main(String[] args) {
        /*SinglyLinkedList list = new SinglyLinkedList();
        list.insertAtEnd(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);
        list.display();*/
		SinglyLinkedList list = new SinglyLinkedList();
        list.insertAtEnd(10);
        list.insertAtEnd(20);
        list.insertAtEnd(30);
        list.display();
        
        list.insertAtBeginning(5);
        list.insertAtPosition(15, 3);
        list.display();

        list.deleteFromBeginning();
        list.deleteFromEnd();
        list.deleteFromPosition(2);
        list.display();
        
        System.out.println("Search 20: " + list.search(20));
        System.out.println("Search 15: " + list.search(15));

        list.reverse();
        list.display();
    }
}
